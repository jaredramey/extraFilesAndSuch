#ifndef _TEXTURE_H_
#define _TEXTURE_H_


unsigned int loadTexture(const char* a_pFilename, int & a_iWidth, int & a_iHeight, int & a_iBPP);

#endif //_TEXTURE_H_