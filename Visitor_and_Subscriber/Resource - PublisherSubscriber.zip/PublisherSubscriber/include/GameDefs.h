#pragma once

const int iScreenWidth = 1280;
const int iScreenHeight = 780;